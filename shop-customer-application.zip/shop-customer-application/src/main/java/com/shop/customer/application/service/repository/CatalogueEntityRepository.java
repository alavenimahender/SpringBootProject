package com.shop.customer.application.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.shop.customer.application.service.entity.CatalogueEntity;

@Repository
public interface CatalogueEntityRepository extends JpaRepository<CatalogueEntity, Integer>{
  @Query("from CatalogueEntity where id=:id")
  CatalogueEntity getCatalogueEntityById(@Param("id") Integer id);
}