package com.shop.customer.application.util;

public class ShopCustomerUtil{}
