package com.shop.customer.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.shop.customer.application"})
public class ShopCustomerApplication{
  public static void main(String[] args) {
    SpringApplication.run(ShopCustomerApplication.class, args);
  }
}