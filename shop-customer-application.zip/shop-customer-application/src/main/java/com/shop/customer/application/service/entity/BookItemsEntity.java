package com.shop.customer.application.service.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "book_items")
public class BookItemsEntity{
  @Id
  @Column(name = "id", unique = true, nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  @Column(name = "item_name")
  private String itemName;
  @Column(name = "quantity")
  private Integer quantity;
  @Column(name = "quantity_total_price")
  private Float quantityTotalPrice;
  @Column(name = "user_id")
  private String userId;
  @Column(name = "active")
  private boolean active;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getItemName() {
    return itemName;
  }

  public void setItemName(String itemName) {
    this.itemName = itemName;
  }

  public Integer getQuantity() {
    return quantity;
  }

  public void setQuantity(Integer quantity) {
    this.quantity = quantity;
  }

  public Float getQuantityTotalPrice() {
    return quantityTotalPrice;
  }

  public void setQuantityTotalPrice(Float quantityTotalPrice) {
    this.quantityTotalPrice = quantityTotalPrice;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + (active? 1231 : 1237);
    result = prime * result + ((id == null)? 0 : id.hashCode());
    result = prime * result + ((itemName == null)? 0 : itemName.hashCode());
    result = prime * result + ((quantity == null)? 0 : quantity.hashCode());
    result = prime * result + ((quantityTotalPrice == null)? 0 : quantityTotalPrice.hashCode());
    result = prime * result + ((userId == null)? 0 : userId.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    BookItemsEntity other = (BookItemsEntity) obj;
    if (active != other.active)
      return false;
    if (id == null) {
      if (other.id != null)
        return false;
    } else if (!id.equals(other.id))
      return false;
    if (itemName == null) {
      if (other.itemName != null)
        return false;
    } else if (!itemName.equals(other.itemName))
      return false;
    if (quantity == null) {
      if (other.quantity != null)
        return false;
    } else if (!quantity.equals(other.quantity))
      return false;
    if (quantityTotalPrice == null) {
      if (other.quantityTotalPrice != null)
        return false;
    } else if (!quantityTotalPrice.equals(other.quantityTotalPrice))
      return false;
    if (userId == null) {
      if (other.userId != null)
        return false;
    } else if (!userId.equals(other.userId))
      return false;
    return true;
  }

  @Override
  public String toString() {
    return "BookItems [id=" + id + ", itemName=" + itemName + ", quantity=" + quantity + ", quantityTotalPrice="
        + quantityTotalPrice + ", userId=" + userId + ", active=" + active + "]";
  }
}
