package com.shop.customer.application.service.repository;

 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.shop.customer.application.service.entity.UserTypeEntity;


@Repository
public interface UserTypeEntityRepository extends JpaRepository<UserTypeEntity, Integer>{
  @Query("from UserTypeEntity where id=:id")
  UserTypeEntity  getUserTypeById(@Param("id") Integer id );
}

