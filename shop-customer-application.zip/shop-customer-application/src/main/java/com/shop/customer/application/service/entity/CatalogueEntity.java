package com.shop.customer.application.service.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "catalogue")
public class CatalogueEntity{
  @Id
  @Column(name = "id", unique = true, nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  @Column(name = "catalogue_name")
  private String catalogueName;
  @Column(name = "image")
  private String image;
  @Column(name = "available_quantity")
  private Integer availableQuantity;
  @Column(name = "unit_price_for_kg_lit")
  private Float unitPriceForKgLit;
  @Column(name = "active")
  private boolean active;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getCatalogueName() {
    return catalogueName;
  }

  public void setCatalogueName(String catalogueName) {
    this.catalogueName = catalogueName;
  }

  public String getImage() {
    return image;
  }

  public void setImage(String image) {
    this.image = image;
  }

  public Integer getAvailableQuantity() {
    return availableQuantity;
  }

  public void setAvailableQuantity(Integer availableQuantity) {
    this.availableQuantity = availableQuantity;
  }

  public Float getUnitPriceForKgLit() {
    return unitPriceForKgLit;
  }

  public void setUnitPriceForKgLit(Float unitPriceForKgLit) {
    this.unitPriceForKgLit = unitPriceForKgLit;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  @Override
  public String toString() {
    return "CatalogueEntity [id=" + id + ", catalogueName=" + catalogueName + ", image=" + image
        + ", availableQuantity=" + availableQuantity + ", unitPriceForKgLit=" + unitPriceForKgLit + ", active=" + active
        + "]";
  }
}
