package com.shop.customer.application.service.model;

public class OrderDetailsModel{
  private Integer id;
  private String name;
  private String description;
  private Integer quantity;
  private String dateTime;
  private String shopOwnerId;
  private String userId;
  private boolean active;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public Integer getQuantity() {
    return quantity;
  }

  public void setQuantity(Integer quantity) {
    this.quantity = quantity;
  }

  public String getDateTime() {
    return dateTime;
  }

  public void setDateTime(String dateTime) {
    this.dateTime = dateTime;
  }

  public String getShopOwnerId() {
    return shopOwnerId;
  }

  public void setShopOwnerId(String shopOwnerId) {
    this.shopOwnerId = shopOwnerId;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  @Override
  public String toString() {
    return "OrderDetailsModel [id=" + id + ", name=" + name + ", description=" + description + ", quantity=" + quantity
        + ", dateTime=" + dateTime + ", shopOwnerId=" + shopOwnerId + ", userId=" + userId + ", active=" + active + "]";
  }
}
