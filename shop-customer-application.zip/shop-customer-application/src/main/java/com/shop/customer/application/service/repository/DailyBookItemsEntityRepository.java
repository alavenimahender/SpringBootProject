package com.shop.customer.application.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.shop.customer.application.service.entity.BookItemsEntity;
import com.shop.customer.application.service.entity.DailyBookItemsEntity;

@Repository
public interface DailyBookItemsEntityRepository extends JpaRepository<DailyBookItemsEntity, Integer>{
  @Query("from DailyBookItemsEntity where id=:id")
  DailyBookItemsEntity getDailyBookItemsEntityById(@Param("id") Integer id);
}