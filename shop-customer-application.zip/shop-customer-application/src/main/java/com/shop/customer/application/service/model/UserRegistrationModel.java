package com.shop.customer.application.service.model;

public class UserRegistrationModel{
  private Integer id;
  private String name;
  private String email;
  private String phone;
  private String type;
  private String country;
  private String state;
  private String city;
  private String village;
  private String zipCode;
  private Double limitAmount;
  private boolean active;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getVillage() {
    return village;
  }

  public void setVillage(String village) {
    this.village = village;
  }

  public String getZipCode() {
    return zipCode;
  }

  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

  public Double getLimitAmount() {
    return limitAmount;
  }

  public void setLimitAmount(Double limitAmount) {
    this.limitAmount = limitAmount;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  @Override
  public String toString() {
    return "UserRegistrationModel [id=" + id + ", name=" + name + ", email=" + email + ", phone=" + phone + ", type="
        + type + ", country=" + country + ", state=" + state + ", city=" + city + ", village=" + village + ", zipCode="
        + zipCode + ", limitAmount=" + limitAmount + ", active=" + active + "]";
  }
}
