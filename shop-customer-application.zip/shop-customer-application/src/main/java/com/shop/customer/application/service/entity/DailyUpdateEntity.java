package com.shop.customer.application.service.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "daily_update")
public class DailyUpdateEntity{
  @Id
  @Column(name = "id", unique = true, nullable = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;
  @Column(name = "first_name")
  private String firstName;
  @Column(name = "last_name")
  private String lastName;
  @Column(name = "shop_name")
  private Integer shopName;
  @Column(name = "balance_amount")
  private Float balanceAmount;
  @Column(name = "transaction_amount")
  private Float transactionAmount;
  @Column(name = "active")
  private boolean active;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public Integer getShopName() {
    return shopName;
  }

  public void setShopName(Integer shopName) {
    this.shopName = shopName;
  }

  public Float getBalanceAmount() {
    return balanceAmount;
  }

  public void setBalanceAmount(Float balanceAmount) {
    this.balanceAmount = balanceAmount;
  }

  public Float getTransactionAmount() {
    return transactionAmount;
  }

  public void setTransactionAmount(Float transactionAmount) {
    this.transactionAmount = transactionAmount;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  @Override
  public String toString() {
    return "DailyUpdateEntity [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", shopName="
        + shopName + ", balanceAmount=" + balanceAmount + ", transactionAmount=" + transactionAmount + ", active="
        + active + "]";
  }
}
