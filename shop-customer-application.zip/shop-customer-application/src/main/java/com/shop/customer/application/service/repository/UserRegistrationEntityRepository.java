package com.shop.customer.application.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.shop.customer.application.service.entity.UserRegistrationEntity;

@Repository
public interface UserRegistrationEntityRepository extends JpaRepository<UserRegistrationEntity, Integer>{
  @Query("from UserRegistrationEntity where id=:id")
  UserRegistrationEntity getUserRegistrationById(@Param("id") Integer id);
  @Query("from UserRegistrationEntity where userName=:userName")
  UserRegistrationEntity getUserRegistrationByUserName(@Param("userName") String userName);
}
