package com.shop.customer.application.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.shop.customer.application.service.entity.BookItemsEntity;
import com.shop.customer.application.service.entity.CatalogueEntity;
import com.shop.customer.application.service.entity.DailyBookItemsEntity;
import com.shop.customer.application.service.entity.DailyUpdateEntity;
import com.shop.customer.application.service.entity.UserRegistrationEntity;
import com.shop.customer.application.service.entity.UserTypeEntity;
import com.shop.customer.application.service.model.LoginUser;
import com.shop.customer.application.service.model.ResponseStatus;
import com.shop.customer.application.service.repository.BookItemsEntityRepository;
import com.shop.customer.application.service.repository.CatalogueEntityRepository;
import com.shop.customer.application.service.repository.DailyBookItemsEntityRepository;
import com.shop.customer.application.service.repository.DailyUpdateEntityRepository;
import com.shop.customer.application.service.repository.UserRegistrationEntityRepository;
import com.shop.customer.application.service.repository.UserTypeEntityRepository;

@RestController
public class ShopCustomerRestController{
  @Autowired
  CatalogueEntityRepository catalogueEntityRepository;
  @Autowired
  UserRegistrationEntityRepository userRegistrationEntityRepository;
  @Autowired
  UserTypeEntityRepository userTypeEntityRepository;
  @Autowired
  BookItemsEntityRepository bookItemsEntityRepository;
  @Autowired
  DailyBookItemsEntityRepository dailyBookItemsEntityRepository;
  @Autowired
  DailyUpdateEntityRepository dailyUpdateEntityRepository;

  @RequestMapping(value = "/listUserType", method = RequestMethod.GET, consumes = "application/json", produces = "application/json")
  public ResponseEntity<List<UserTypeEntity>> listUserType() {
    List<UserTypeEntity> listUserType = userTypeEntityRepository.findAll();
    return new ResponseEntity<List<UserTypeEntity>>(listUserType, HttpStatus.OK);
  }

  @RequestMapping(value = "/addUserType", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
  public ResponseEntity<UserTypeEntity> addUserType(@RequestBody UserTypeEntity userTypeEntity) {
    UserTypeEntity updatedUserTypeEntity = userTypeEntityRepository.save(userTypeEntity);
    return new ResponseEntity<UserTypeEntity>(updatedUserTypeEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/updateUserType", method = RequestMethod.PUT, consumes = "application/json", produces = "application/json")
  public ResponseEntity<UserTypeEntity> updateUserType(@RequestBody UserTypeEntity userTypeEntity) {
    UserTypeEntity updatedUserTypeEntity = userTypeEntityRepository.save(userTypeEntity);
    return new ResponseEntity<UserTypeEntity>(updatedUserTypeEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/updateUserType/{id}", method = RequestMethod.GET, consumes = "application/json", produces = "application/json")
  public ResponseEntity<UserTypeEntity> getUserType(@PathVariable("id") Integer id) {
    UserTypeEntity updatedUserTypeEntity = userTypeEntityRepository.getUserTypeById(id);
    return new ResponseEntity<UserTypeEntity>(updatedUserTypeEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/deleteUserType", method = RequestMethod.DELETE, consumes = "application/json", produces = "application/json")
  public ResponseEntity<ResponseStatus> deleteUserType(@RequestBody UserTypeEntity userTypeEntity) {
    userTypeEntityRepository.delete(userTypeEntity);
    ResponseStatus responseStatus = new ResponseStatus();
    responseStatus.setCode("DELETE");
    responseStatus.setMessage("Successfully deleted the user type");
    return new ResponseEntity<ResponseStatus>(responseStatus, HttpStatus.OK);
  }

  @RequestMapping(value = "/listUserRegistration", method = RequestMethod.GET, consumes = "application/json", produces = "application/json")
  public ResponseEntity<List<UserRegistrationEntity>> listUserRegistration() {
    List<UserRegistrationEntity> listuserRegistration = userRegistrationEntityRepository.findAll();
    return new ResponseEntity<List<UserRegistrationEntity>>(listuserRegistration, HttpStatus.OK);
  }

  @RequestMapping(value = "/addUserRegistration", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
  public ResponseEntity<UserRegistrationEntity> addUserRegistration(
      @RequestBody UserRegistrationEntity userRegistrationEntity) {
    UserRegistrationEntity updatedUserRegistrationEntity = userRegistrationEntityRepository
        .save(userRegistrationEntity);
    return new ResponseEntity<UserRegistrationEntity>(updatedUserRegistrationEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/updateUserRegistration", method = RequestMethod.PUT, consumes = "application/json", produces = "application/json")
  public ResponseEntity<UserRegistrationEntity> updateUserRegistration(
      @RequestBody UserRegistrationEntity userRegistrationEntity) {
    UserRegistrationEntity updatedUserRegistrationEntity = userRegistrationEntityRepository
        .save(userRegistrationEntity);
    return new ResponseEntity<UserRegistrationEntity>(updatedUserRegistrationEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/updateUserRegistration/{id}", method = RequestMethod.GET, consumes = "application/json", produces = "application/json")
  public ResponseEntity<UserRegistrationEntity> getUserRegistration(@PathVariable("id") Integer id) {
    UserRegistrationEntity updatedUserRegistrationEntity = userRegistrationEntityRepository.getUserRegistrationById(id);
    return new ResponseEntity<UserRegistrationEntity>(updatedUserRegistrationEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/deleteUserRegistration", method = RequestMethod.DELETE, consumes = "application/json", produces = "application/json")
  public ResponseEntity<ResponseStatus> deleteUserRegistration(
      @RequestBody UserRegistrationEntity userRegistrationEntity) {
    userRegistrationEntityRepository.delete(userRegistrationEntity);
    ResponseStatus responseStatus = new ResponseStatus();
    responseStatus.setCode("DELETE");
    responseStatus.setMessage("Successfully deleted the user");
    return new ResponseEntity<ResponseStatus>(responseStatus, HttpStatus.OK);
  }

  @RequestMapping(value = "/listBookItem", method = RequestMethod.GET, consumes = "application/json", produces = "application/json")
  public ResponseEntity<List<BookItemsEntity>> listBookItem() {
    List<BookItemsEntity> listBookItemsEntity = bookItemsEntityRepository.findAll();
    return new ResponseEntity<List<BookItemsEntity>>(listBookItemsEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/addBookItems", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
  public ResponseEntity<BookItemsEntity> addBookItem(@RequestBody BookItemsEntity bookItemsEntity) {
    BookItemsEntity updatedBookItemsEntity = bookItemsEntityRepository.save(bookItemsEntity);
    return new ResponseEntity<BookItemsEntity>(updatedBookItemsEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/updateBookItems", method = RequestMethod.PUT, consumes = "application/json", produces = "application/json")
  public ResponseEntity<BookItemsEntity> updateBookItem(@RequestBody BookItemsEntity bookItemsEntity) {
    BookItemsEntity updatedBookItemsEntity = bookItemsEntityRepository.save(bookItemsEntity);
    return new ResponseEntity<BookItemsEntity>(updatedBookItemsEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/getBookItems/{id}", method = RequestMethod.GET, consumes = "application/json", produces = "application/json")
  public ResponseEntity<BookItemsEntity> getBookItemById(@PathVariable("id") Integer id) {
    BookItemsEntity updatedBookItemsEntity = bookItemsEntityRepository.getBookItemsEntityById(id);
    return new ResponseEntity<BookItemsEntity>(updatedBookItemsEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/deleteBookItem", method = RequestMethod.DELETE, consumes = "application/json", produces = "application/json")
  public ResponseEntity<ResponseStatus> deleteBookItem(@RequestBody BookItemsEntity bookItemsEntity) {
    bookItemsEntityRepository.delete(bookItemsEntity);
    ResponseStatus responseStatus = new ResponseStatus();
    responseStatus.setCode("DELETE");
    responseStatus.setMessage("Successfully deleted the order details");
    return new ResponseEntity<ResponseStatus>(responseStatus, HttpStatus.OK);
  }

  @RequestMapping(value = "/listCatalogue", method = RequestMethod.GET, consumes = "application/json", produces = "application/json")
  public ResponseEntity<List<CatalogueEntity>> listCatalogueEntity() {
    List<CatalogueEntity> listCatalogueEntity = catalogueEntityRepository.findAll();
    return new ResponseEntity<List<CatalogueEntity>>(listCatalogueEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/addCatalogue", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
  public ResponseEntity<CatalogueEntity> addCatalogue(@RequestBody CatalogueEntity catalogueEntity) {
    CatalogueEntity updatedCatalogueEntity = catalogueEntityRepository.save(catalogueEntity);
    return new ResponseEntity<CatalogueEntity>(updatedCatalogueEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/updateCatalogue", method = RequestMethod.PUT, consumes = "application/json", produces = "application/json")
  public ResponseEntity<CatalogueEntity> updateCatalogue(@RequestBody CatalogueEntity catalogueEntity) {
    CatalogueEntity updatedOrderDetailsEntity = catalogueEntityRepository.save(catalogueEntity);
    return new ResponseEntity<CatalogueEntity>(updatedOrderDetailsEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/getCatalogue/{id}", method = RequestMethod.GET, consumes = "application/json", produces = "application/json")
  public ResponseEntity<CatalogueEntity> getCatalogue(@PathVariable("id") Integer id) {
    CatalogueEntity updatedCatalogueEntity = catalogueEntityRepository.getCatalogueEntityById(id);
    return new ResponseEntity<CatalogueEntity>(updatedCatalogueEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/deleteCatalogue", method = RequestMethod.DELETE, consumes = "application/json", produces = "application/json")
  public ResponseEntity<ResponseStatus> deleteCatalogue(@RequestBody CatalogueEntity catalogueEntity) {
    catalogueEntityRepository.delete(catalogueEntity);
    ResponseStatus responseStatus = new ResponseStatus();
    responseStatus.setCode("DELETE");
    responseStatus.setMessage("Successfully deleted the order details");
    return new ResponseEntity<ResponseStatus>(responseStatus, HttpStatus.OK);
  }

  @RequestMapping(value = "/forgotpassword", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
  public ResponseEntity<UserRegistrationEntity> forgotpassword(
      @RequestBody UserRegistrationEntity userRegistrationEntity) {
    UserRegistrationEntity existingUserRegistrationEntity = userRegistrationEntityRepository
        .getUserRegistrationByUserName(userRegistrationEntity.getUserName());
    existingUserRegistrationEntity.setPassword(userRegistrationEntity.getPassword());
    existingUserRegistrationEntity.setConfirmPassword(userRegistrationEntity.getConfirmPassword());
    userRegistrationEntityRepository.save(existingUserRegistrationEntity);
    return new ResponseEntity<UserRegistrationEntity>(existingUserRegistrationEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/checkUserExist", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
  public ResponseEntity<UserRegistrationEntity> checkUserExist(@RequestBody LoginUser loginUser) {
    UserRegistrationEntity existingUserRegistrationEntity = userRegistrationEntityRepository
        .getUserRegistrationByUserName(loginUser.getUserName());
    return new ResponseEntity<UserRegistrationEntity>(existingUserRegistrationEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/listDailyBookItems", method = RequestMethod.GET, consumes = "application/json", produces = "application/json")
  public ResponseEntity<List<DailyBookItemsEntity>> listDailyBookItems() {
    List<DailyBookItemsEntity> listDailyBookItemsEntity = dailyBookItemsEntityRepository.findAll();
    return new ResponseEntity<List<DailyBookItemsEntity>>(listDailyBookItemsEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/addDailyBookItems", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
  public ResponseEntity<DailyBookItemsEntity> addDailyBookItems(
      @RequestBody DailyBookItemsEntity dailyBookItemsEntity) {
    DailyBookItemsEntity updatedCatalogueEntity = dailyBookItemsEntityRepository.save(dailyBookItemsEntity);
    return new ResponseEntity<DailyBookItemsEntity>(updatedCatalogueEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/updateDailyBookItems", method = RequestMethod.PUT, consumes = "application/json", produces = "application/json")
  public ResponseEntity<DailyBookItemsEntity> updateDailyBookItems(
      @RequestBody DailyBookItemsEntity dailyBookItemsEntity) {
    DailyBookItemsEntity updatedDailyBookItemsEntity = dailyBookItemsEntityRepository.save(dailyBookItemsEntity);
    return new ResponseEntity<DailyBookItemsEntity>(updatedDailyBookItemsEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/getDailyBookItems/{id}", method = RequestMethod.GET, consumes = "application/json", produces = "application/json")
  public ResponseEntity<DailyBookItemsEntity> getCDailyBookItems(@PathVariable("id") Integer id) {
    DailyBookItemsEntity updatedDailyBookItemsEntity = dailyBookItemsEntityRepository.getDailyBookItemsEntityById(id);
    return new ResponseEntity<DailyBookItemsEntity>(updatedDailyBookItemsEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/deleteDailyBookItems", method = RequestMethod.DELETE, consumes = "application/json", produces = "application/json")
  public ResponseEntity<ResponseStatus> deleteDailyBookItems(@RequestBody DailyBookItemsEntity dailyBookItemsEntity) {
    dailyBookItemsEntityRepository.delete(dailyBookItemsEntity);
    ResponseStatus responseStatus = new ResponseStatus();
    responseStatus.setCode("DELETE");
    responseStatus.setMessage("Successfully deleted the order details");
    return new ResponseEntity<ResponseStatus>(responseStatus, HttpStatus.OK);
  }

  @RequestMapping(value = "/listDailyUpdate", method = RequestMethod.GET, consumes = "application/json", produces = "application/json")
  public ResponseEntity<List<DailyUpdateEntity>> listDailyUpdate() {
    List<DailyUpdateEntity> listDailyUpdateEntity = dailyUpdateEntityRepository.findAll();
    return new ResponseEntity<List<DailyUpdateEntity>>(listDailyUpdateEntity, HttpStatus.OK);
  }

  @RequestMapping(value = "/addDailyUpdate", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
  public ResponseEntity<DailyUpdateEntity> addDailyBookItems(@RequestBody DailyUpdateEntity dailyUpdateEntity) {
    DailyUpdateEntity updatedDailyBookItemsEntity = dailyUpdateEntityRepository.save(dailyUpdateEntity);
    return new ResponseEntity<DailyUpdateEntity>(updatedDailyBookItemsEntity, HttpStatus.OK);
  }
}
